package crud_example.dao;

import java.util.List;

import crud_example.model.users;

public interface UserDao {
 
 public List getListUser();
 
 public void saveOrUpdate(users user);
 
 public void deleteUser(int id);
 
 public users findUserById(int id);
 
 public users findUserInfo(String username);
 
 public List<String> getUserRoles(String username);
 
}
