package crud_example.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;


import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Repository;

import  crud_example.model.users;

@Repository
public class UserDaoImpl implements UserDao {
	NamedParameterJdbcTemplate namedParameterJdbcTemplate;
 @Autowired
 private SessionFactory sessionFactory;
 
 protected Session getSession(){
  return sessionFactory.getCurrentSession();
 }

 @SuppressWarnings("unchecked")
 public List getListUser() {
  Criteria criteria = getSession().createCriteria(users.class);
  
  return (List) criteria.list();
 }

 public void saveOrUpdate(users user) {
  getSession().saveOrUpdate(user);
 }

 public void deleteUser(int id) {
	 users user = (users) getSession().get(users.class, id);
  getSession().delete(user);
 }

 public users findUserById(int id) {
  return (users) getSession().get(users.class, id);
 }

public users findUserInfo(String username) {
	String query = "select * from users where username=:username";
	
	try {
	users usersInfo = namedParameterJdbcTemplate.queryForObject(query, getSqlParameterByModel(username,""), new UserInfoMapper());
     return usersInfo;
	}catch(EmptyResultDataAccessException e) {
		return null;
	}
	
}

private SqlParameterSource getSqlParameterByModel(String username,String password) {
	MapSqlParameterSource paramSource = new MapSqlParameterSource();
	paramSource.addValue("username", username);
	paramSource.addValue("password", password);
	return paramSource;
}


private static final class UserInfoMapper implements RowMapper<users>{
	
	public users mapRow(ResultSet rs, int rowNum)throws SQLException{
		
		String userName = rs.getString("username");
		String password = rs.getString("password");
		
		return new users(userName,password);
		
	}
	
}


public List<String> getUserRoles(String username) {
    String query = "select perfil from users where username = :username";
    
    List<String> roles = namedParameterJdbcTemplate.queryForList(query, getSqlParameterByModel(username,""),String.class);
    
	return roles;
}


}
