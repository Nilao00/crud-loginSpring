package crud_example.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="users")
public class users {

	public users(String username,String password) {
		super();
		this.username = username;
		this.password = password;
	}

 @Id
 @GeneratedValue(strategy= GenerationType.IDENTITY)
 private int id;
 
 @Column(name="name", nullable=true)
 private String name;

 @Column(name="address", nullable=true)
 private String address;
 @Column(name="telefone", nullable=true)
 private String telefone;

 @Column(name="username", nullable=true)
 private String username;
 @Column(name="password", nullable=true)
 private String password;
 
 @Column(name="perfil", nullable=true)
 private int perfil;
 
 
 public String getUsername() {
	return username;
}

public void setUsername(String username) {
	this.username = username;
}

public String getPassword() {
	return password;
}

public void setPassword(String password) {
	this.password = password;
}

public int getPerfil() {
	return perfil;
}

public void setPerfil(int perfil) {
	this.perfil = perfil;
}

public int getId() {
  return id;
 }

 public void setId(int id) {
  this.id = id;
 }

 public String getName() {
  return name;
 }

 public void setName(String name) {
  this.name = name;
 }
 
 public String getTelefone() {
  return telefone;
 }
public void setTelefone(String telefone) {
  this.telefone = telefone;
 }
 
public String getAddress() {
 return address;
}
public void setAddress(String address) {
 this.address = address;
}

 
}
