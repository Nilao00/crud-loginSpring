package crud_example.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import  crud_example.service.UserService;
import  crud_example.model.users;

@RestController
public class UserController {

 @Autowired
 UserService userService;
 
 @RequestMapping(value="/login/", method=RequestMethod.POST)
 public ModelAndView login(@RequestParam(value="error",required=false)String error) {
	 ModelAndView model = new ModelAndView();
	 if(error==null) {
		 model.addObject("error","Usuario ou senha incorretos");
	 }
	 model.addObject("message",true);
	 
	 return model;
 }

 
 
 @RequestMapping(value="/user/", method=RequestMethod.GET, headers="Accept=application/json")
 public @ResponseBody List getListUser(){
	 
  List users = userService.getListUser();
  
	  return  users;
  
  
	 
  
 }
 @RequestMapping(value="/user/{id}", method=RequestMethod.GET, headers="Accept=application/json")
 public @ResponseBody users find(@PathVariable("id") int id){
 users user = userService.findUserById(id);
  userService.findUserById(id);
  
 if(id != 0 ) {
	  
	 return  user;
	 
  }else {
	  user = null;
	  user.setId(0);
	  return user;
	  
	  
  
  }
 }
 
 @RequestMapping(value="/add/", method=RequestMethod.POST)
 public @ResponseBody users add(@RequestBody users user){
  user = (users) userService.getListUser();
   

  userService.saveOrUpdate(user);
 
  return user;
  
 }
 
 @RequestMapping(value="/update/{id}", method=RequestMethod.PUT)
 public @ResponseBody users update(@PathVariable("id") int id, @RequestBody users user){
  user.setId(id);
  userService.saveOrUpdate(user);
  
  return user;
 }
 
 @RequestMapping(value="/delete/{id}", method=RequestMethod.DELETE)
 public @ResponseBody users delete(@PathVariable("id") int id){
 users user = userService.findUserById(id);
  userService.deleteUser(id);
  
  return user;
 }


}
