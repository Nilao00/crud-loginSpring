package crud_example.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import  crud_example.dao.UserDao;
import  crud_example.model.users;

@Service
@Transactional
public class UserServiceImpl implements UserService {
 
 UserDao userDao;
 
 @Autowired
 public void setUserDao(UserDao userDao) {
  this.userDao = userDao;
 }

 public List getListUser() {
  return userDao.getListUser();
 }

 public void saveOrUpdate(users user) {
  userDao.saveOrUpdate(user);
 }

 public void deleteUser(int id) {
  userDao.deleteUser(id);
 }

 public users findUserById(int id) {
  return userDao.findUserById(id);
 }
 
 public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException{
	 users userInfo = userDao.findUserInfo(username);
	 if(userInfo == null) {
		 throw new UsernameNotFoundException("username was not found in the database");
		 		 
	 }
	 List<String> roles = userDao.getUserRoles(username);
	 List<GrantedAuthority> grantList = new ArrayList<GrantedAuthority>();
	 if(roles != null) {
		 for(String role:roles) {
			 GrantedAuthority authority = new SimpleGrantedAuthority(role);
			 grantList.add(authority);
		 }
	 }
	 
	 UserDetails userDetails =  new User(userInfo.getUsername(),userInfo.getPassword(),grantList);
	 
	 return userDetails;
 }



}
