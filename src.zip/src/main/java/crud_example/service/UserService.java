package crud_example.service;

import java.util.List;

import org.springframework.security.core.userdetails.UserDetails;

import  crud_example.model.users;

public interface UserService {
 
 public List getListUser();
 
 public void saveOrUpdate(users user);
 
 public void deleteUser(int id);
 
 public users findUserById(int id);

 public UserDetails loadUserByUsername(String username);
}
